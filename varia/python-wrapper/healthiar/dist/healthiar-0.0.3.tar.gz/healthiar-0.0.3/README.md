# healthiar

[![PyPI - Version](https://img.shields.io/pypi/v/healthiar.svg)](https://pypi.org/project/healthiar)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/healthiar.svg)](https://pypi.org/project/healthiar)

-----

## Table of Contents

- [Installation](#installation)
- [Documentation](#documentation)
- [License](#license)

## Installation

```console
pip install healthiar
```

## Documentation

For the documentation on using `healthiar`, we refer to the R package documentation:
- [Intro to healthiar](https://swisstph.github.io/healthiar/articles/intro_to_healthiar.html#python-wrapper) vignette;
- [Reference page](https://swisstph.github.io/healthiar/reference/index.html) of the package website.

## License

`healthiar` is distributed under the terms of the [GPL-3.0-only](https://spdx.org/licenses/GPL-3.0-only.html) license.
