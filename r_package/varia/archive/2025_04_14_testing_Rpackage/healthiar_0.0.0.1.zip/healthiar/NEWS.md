# healthiar (development version)

* Initial CRAN submission.

## New Features
- Added `awesome_function()`

## Bug Fixes

* Corrected typos in help documentation

## Improvements

* Many
